library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity DCT8x8rc_Bas11a_v1_0_S00_AXI is
	generic (
		-- Users to add parameters here

		-- User parameters ends
		-- Do not modify the parameters beyond this line

		-- Width of S_AXI data bus
		C_S_AXI_DATA_WIDTH	: integer	:= 32;
		-- Width of S_AXI address bus
		C_S_AXI_ADDR_WIDTH	: integer	:= 9
	);
	port (
		-- Users to add ports here

		-- User ports ends
		-- Do not modify the ports beyond this line

		-- Global Clock Signal
		S_AXI_ACLK	: in std_logic;
		-- Global Reset Signal. This Signal is Active LOW
		S_AXI_ARESETN	: in std_logic;
		-- Write address (issued by master, acceped by Slave)
		S_AXI_AWADDR	: in std_logic_vector(C_S_AXI_ADDR_WIDTH-1 downto 0);
		-- Write channel Protection type. This signal indicates the
    		-- privilege and security level of the transaction, and whether
    		-- the transaction is a data access or an instruction access.
		S_AXI_AWPROT	: in std_logic_vector(2 downto 0);
		-- Write address valid. This signal indicates that the master signaling
    		-- valid write address and control information.
		S_AXI_AWVALID	: in std_logic;
		-- Write address ready. This signal indicates that the slave is ready
    		-- to accept an address and associated control signals.
		S_AXI_AWREADY	: out std_logic;
		-- Write data (issued by master, acceped by Slave) 
		S_AXI_WDATA	: in std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
		-- Write strobes. This signal indicates which byte lanes hold
    		-- valid data. There is one write strobe bit for each eight
    		-- bits of the write data bus.    
		S_AXI_WSTRB	: in std_logic_vector((C_S_AXI_DATA_WIDTH/8)-1 downto 0);
		-- Write valid. This signal indicates that valid write
    		-- data and strobes are available.
		S_AXI_WVALID	: in std_logic;
		-- Write ready. This signal indicates that the slave
    		-- can accept the write data.
		S_AXI_WREADY	: out std_logic;
		-- Write response. This signal indicates the status
    		-- of the write transaction.
		S_AXI_BRESP	: out std_logic_vector(1 downto 0);
		-- Write response valid. This signal indicates that the channel
    		-- is signaling a valid write response.
		S_AXI_BVALID	: out std_logic;
		-- Response ready. This signal indicates that the master
    		-- can accept a write response.
		S_AXI_BREADY	: in std_logic;
		-- Read address (issued by master, acceped by Slave)
		S_AXI_ARADDR	: in std_logic_vector(C_S_AXI_ADDR_WIDTH-1 downto 0);
		-- Protection type. This signal indicates the privilege
    		-- and security level of the transaction, and whether the
    		-- transaction is a data access or an instruction access.
		S_AXI_ARPROT	: in std_logic_vector(2 downto 0);
		-- Read address valid. This signal indicates that the channel
    		-- is signaling valid read address and control information.
		S_AXI_ARVALID	: in std_logic;
		-- Read address ready. This signal indicates that the slave is
    		-- ready to accept an address and associated control signals.
		S_AXI_ARREADY	: out std_logic;
		-- Read data (issued by slave)
		S_AXI_RDATA	: out std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
		-- Read response. This signal indicates the status of the
    		-- read transfer.
		S_AXI_RRESP	: out std_logic_vector(1 downto 0);
		-- Read valid. This signal indicates that the channel is
    		-- signaling the required read data.
		S_AXI_RVALID	: out std_logic;
		-- Read ready. This signal indicates that the master can
    		-- accept the read data and response information.
		S_AXI_RREADY	: in std_logic
	);
end DCT8x8rc_Bas11a_v1_0_S00_AXI;

architecture arch_imp of DCT8x8rc_Bas11a_v1_0_S00_AXI is

        ---mis se�ales
    TYPE matrix IS ARRAY (0 TO 7, 0 TO 7) OF SIGNED(15 downto 0) ;
   -- TYPE matrixr IS ARRAY (0 TO 7, 0 TO 7) OF SIGNED(44 downto 0);
    TYPE cosine IS ARRAY (0 TO 7) OF SIGNED(15 downto 0);
    --se pueden cambiar por 8 bits 2^8
    constant alpha : cosine := (to_signed(0,16),to_signed(11585,16),to_signed(8867,16),to_signed(11585,16),to_signed(21407,16),to_signed(6270,16),to_signed(8192,16),to_signed(8192,16));
    signal al: signed(15 downto 0);
    
    signal mat: matrix ;
    signal mat2: matrix ;
	-- AXI4LITE signals
	signal axi_awaddr	: std_logic_vector(C_S_AXI_ADDR_WIDTH-1 downto 0);
	signal axi_awready	: std_logic;
	signal axi_wready	: std_logic;
	signal axi_bresp	: std_logic_vector(1 downto 0);
	signal axi_bvalid	: std_logic;
	signal axi_araddr	: std_logic_vector(C_S_AXI_ADDR_WIDTH-1 downto 0);
	signal axi_arready	: std_logic;
	signal axi_rdata	: std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal axi_rresp	: std_logic_vector(1 downto 0);
	signal axi_rvalid	: std_logic;

	-- Example-specific design signals
	-- local parameter for addressing 32 bit / 64 bit C_S_AXI_DATA_WIDTH
	-- ADDR_LSB is used for addressing 32/64 bit registers/memories
	-- ADDR_LSB = 2 for 32 bits (n downto 2)
	-- ADDR_LSB = 3 for 64 bits (n downto 3)
	constant ADDR_LSB  : integer := (C_S_AXI_DATA_WIDTH/32)+ 1;
	constant OPT_MEM_ADDR_BITS : integer := 6;
	------------------------------------------------
	---- Signals for user logic register space example
	--------------------------------------------------
	---- Number of Slave Registers 65
	signal slv_reg0	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg1	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg2	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg3	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg4	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg5	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg6	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg7	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg8	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg9	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg10	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg11	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg12	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg13	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg14	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg15	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg16	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg17	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg18	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg19	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg20	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg21	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg22	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg23	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg24	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg25	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg26	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg27	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg28	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg29	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg30	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg31	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg32	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg33	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg34	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg35	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg36	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg37	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg38	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg39	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg40	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg41	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg42	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg43	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg44	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg45	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg46	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg47	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg48	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg49	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg50	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg51	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg52	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg53	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg54	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg55	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg56	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg57	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg58	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg59	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg60	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg61	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg62	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg63	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg64	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal slv_reg_rden	: std_logic;
	signal slv_reg_wren	: std_logic;
	signal reg_data_out	:std_logic_vector(C_S_AXI_DATA_WIDTH-1 downto 0);
	signal byte_index	: integer;
	signal aw_en	: std_logic;

begin
	-- I/O Connections assignments

	S_AXI_AWREADY	<= axi_awready;
	S_AXI_WREADY	<= axi_wready;
	S_AXI_BRESP	<= axi_bresp;
	S_AXI_BVALID	<= axi_bvalid;
	S_AXI_ARREADY	<= axi_arready;
	S_AXI_RDATA	<= axi_rdata;
	S_AXI_RRESP	<= axi_rresp;
	S_AXI_RVALID	<= axi_rvalid;
	-- Implement axi_awready generation
	-- axi_awready is asserted for one S_AXI_ACLK clock cycle when both
	-- S_AXI_AWVALID and S_AXI_WVALID are asserted. axi_awready is
	-- de-asserted when reset is low.

	process (S_AXI_ACLK)
	begin
	  if rising_edge(S_AXI_ACLK) then 
	    if S_AXI_ARESETN = '0' then
	      axi_awready <= '0';
	      aw_en <= '1';
	    else
	      if (axi_awready = '0' and S_AXI_AWVALID = '1' and S_AXI_WVALID = '1' and aw_en = '1') then
	        -- slave is ready to accept write address when
	        -- there is a valid write address and write data
	        -- on the write address and data bus. This design 
	        -- expects no outstanding transactions. 
	           axi_awready <= '1';
	           aw_en <= '0';
	        elsif (S_AXI_BREADY = '1' and axi_bvalid = '1') then
	           aw_en <= '1';
	           axi_awready <= '0';
	      else
	        axi_awready <= '0';
	      end if;
	    end if;
	  end if;
	end process;

	-- Implement axi_awaddr latching
	-- This process is used to latch the address when both 
	-- S_AXI_AWVALID and S_AXI_WVALID are valid. 

	process (S_AXI_ACLK)
	begin
	  if rising_edge(S_AXI_ACLK) then 
	    if S_AXI_ARESETN = '0' then
	      axi_awaddr <= (others => '0');
	    else
	      if (axi_awready = '0' and S_AXI_AWVALID = '1' and S_AXI_WVALID = '1' and aw_en = '1') then
	        -- Write Address latching
	        axi_awaddr <= S_AXI_AWADDR;
	      end if;
	    end if;
	  end if;                   
	end process; 

	-- Implement axi_wready generation
	-- axi_wready is asserted for one S_AXI_ACLK clock cycle when both
	-- S_AXI_AWVALID and S_AXI_WVALID are asserted. axi_wready is 
	-- de-asserted when reset is low. 

	process (S_AXI_ACLK)
	begin
	  if rising_edge(S_AXI_ACLK) then 
	    if S_AXI_ARESETN = '0' then
	      axi_wready <= '0';
	    else
	      if (axi_wready = '0' and S_AXI_WVALID = '1' and S_AXI_AWVALID = '1' and aw_en = '1') then
	          -- slave is ready to accept write data when 
	          -- there is a valid write address and write data
	          -- on the write address and data bus. This design 
	          -- expects no outstanding transactions.           
	          axi_wready <= '1';
	      else
	        axi_wready <= '0';
	      end if;
	    end if;
	  end if;
	end process; 

	-- Implement memory mapped register select and write logic generation
	-- The write data is accepted and written to memory mapped registers when
	-- axi_awready, S_AXI_WVALID, axi_wready and S_AXI_WVALID are asserted. Write strobes are used to
	-- select byte enables of slave registers while writing.
	-- These registers are cleared when reset (active low) is applied.
	-- Slave register write enable is asserted when valid address and data are available
	-- and the slave is ready to accept the write address and write data.
	slv_reg_wren <= axi_wready and S_AXI_WVALID and axi_awready and S_AXI_AWVALID ;

	process (S_AXI_ACLK)
	variable loc_addr :std_logic_vector(OPT_MEM_ADDR_BITS downto 0); 
	begin
	  if rising_edge(S_AXI_ACLK) then 
	    if S_AXI_ARESETN = '0' then
	      slv_reg0 <= (others => '0');
	      slv_reg1 <= (others => '0');
	      slv_reg2 <= (others => '0');
	      slv_reg3 <= (others => '0');
	      slv_reg4 <= (others => '0');
	      slv_reg5 <= (others => '0');
	      slv_reg6 <= (others => '0');
	      slv_reg7 <= (others => '0');
	      slv_reg8 <= (others => '0');
	      slv_reg9 <= (others => '0');
	      slv_reg10 <= (others => '0');
	      slv_reg11 <= (others => '0');
	      slv_reg12 <= (others => '0');
	      slv_reg13 <= (others => '0');
	      slv_reg14 <= (others => '0');
	      slv_reg15 <= (others => '0');
	      slv_reg16 <= (others => '0');
	      slv_reg17 <= (others => '0');
	      slv_reg18 <= (others => '0');
	      slv_reg19 <= (others => '0');
	      slv_reg20 <= (others => '0');
	      slv_reg21 <= (others => '0');
	      slv_reg22 <= (others => '0');
	      slv_reg23 <= (others => '0');
	      slv_reg24 <= (others => '0');
	      slv_reg25 <= (others => '0');
	      slv_reg26 <= (others => '0');
	      slv_reg27 <= (others => '0');
	      slv_reg28 <= (others => '0');
	      slv_reg29 <= (others => '0');
	      slv_reg30 <= (others => '0');
	      slv_reg31 <= (others => '0');
--	      slv_reg32 <= (others => '0');
--	      slv_reg33 <= (others => '0');
--	      slv_reg34 <= (others => '0');
--	      slv_reg35 <= (others => '0');
--	      slv_reg36 <= (others => '0');
--	      slv_reg37 <= (others => '0');
--	      slv_reg38 <= (others => '0');
--	      slv_reg39 <= (others => '0');
--	      slv_reg40 <= (others => '0');
--	      slv_reg41 <= (others => '0');
--	      slv_reg42 <= (others => '0');
--	      slv_reg43 <= (others => '0');
--	      slv_reg44 <= (others => '0');
--	      slv_reg45 <= (others => '0');
--	      slv_reg46 <= (others => '0');
--	      slv_reg47 <= (others => '0');
--	      slv_reg48 <= (others => '0');
--	      slv_reg49 <= (others => '0');
--	      slv_reg50 <= (others => '0');
--	      slv_reg51 <= (others => '0');
--	      slv_reg52 <= (others => '0');
--	      slv_reg53 <= (others => '0');
--	      slv_reg54 <= (others => '0');
--	      slv_reg55 <= (others => '0');
--	      slv_reg56 <= (others => '0');
--	      slv_reg57 <= (others => '0');
--	      slv_reg58 <= (others => '0');
--	      slv_reg59 <= (others => '0');
--	      slv_reg60 <= (others => '0');
--	      slv_reg61 <= (others => '0');
--	      slv_reg62 <= (others => '0');
--	      slv_reg63 <= (others => '0');
	      slv_reg64 <= (others => '0');
	    else
	      loc_addr := axi_awaddr(ADDR_LSB + OPT_MEM_ADDR_BITS downto ADDR_LSB);
	      if (slv_reg_wren = '1') then
	        case loc_addr is
	          when b"0000000" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 0
	                slv_reg0(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0000001" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 1
	                slv_reg1(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0000010" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 2
	                slv_reg2(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0000011" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 3
	                slv_reg3(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0000100" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 4
	                slv_reg4(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0000101" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 5
	                slv_reg5(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0000110" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 6
	                slv_reg6(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0000111" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 7
	                slv_reg7(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0001000" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 8
	                slv_reg8(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0001001" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 9
	                slv_reg9(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0001010" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 10
	                slv_reg10(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0001011" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 11
	                slv_reg11(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0001100" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 12
	                slv_reg12(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0001101" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 13
	                slv_reg13(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0001110" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 14
	                slv_reg14(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0001111" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 15
	                slv_reg15(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0010000" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 16
	                slv_reg16(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0010001" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 17
	                slv_reg17(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0010010" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 18
	                slv_reg18(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0010011" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 19
	                slv_reg19(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0010100" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 20
	                slv_reg20(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0010101" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 21
	                slv_reg21(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0010110" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 22
	                slv_reg22(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0010111" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 23
	                slv_reg23(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0011000" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 24
	                slv_reg24(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0011001" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 25
	                slv_reg25(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0011010" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 26
	                slv_reg26(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0011011" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 27
	                slv_reg27(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0011100" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 28
	                slv_reg28(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0011101" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 29
	                slv_reg29(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0011110" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 30
	                slv_reg30(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0011111" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 31
	                slv_reg31(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0100000" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 32
	                --slv_reg32(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0100001" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 33
	                --slv_reg33(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0100010" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 34
	                --slv_reg34(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0100011" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 35
	                --slv_reg35(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0100100" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 36
	                --slv_reg36(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0100101" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 37
	                --slv_reg37(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0100110" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 38
	                --slv_reg38(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0100111" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 39
	                --slv_reg39(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0101000" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 40
	                --slv_reg40(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0101001" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 41
	                --slv_reg41(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0101010" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 42
	                --slv_reg42(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0101011" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 43
	                --slv_reg43(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0101100" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 44
	                --slv_reg44(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0101101" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 45
	                --slv_reg45(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0101110" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 46
	                --slv_reg46(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0101111" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 47
	                --slv_reg47(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0110000" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 48
	                --slv_reg48(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0110001" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 49
	                --slv_reg49(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0110010" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 50
	                --slv_reg50(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0110011" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 51
	                --slv_reg51(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0110100" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 52
	                --slv_reg52(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0110101" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 53
	                --slv_reg53(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0110110" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 54
	                --slv_reg54(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0110111" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 55
	                --slv_reg55(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0111000" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 56
	                --slv_reg56(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0111001" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 57
	                --slv_reg57(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0111010" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 58
	                --slv_reg58(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0111011" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 59
	                --slv_reg59(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0111100" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 60
	                --slv_reg60(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0111101" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 61
	                --slv_reg61(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0111110" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 62
	                --slv_reg62(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"0111111" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 63
	                --slv_reg63(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when b"1000000" =>
	            for byte_index in 0 to (C_S_AXI_DATA_WIDTH/8-1) loop
	              if ( S_AXI_WSTRB(byte_index) = '1' ) then
	                -- Respective byte enables are asserted as per write strobes                   
	                -- slave registor 64
	                slv_reg64(byte_index*8+7 downto byte_index*8) <= S_AXI_WDATA(byte_index*8+7 downto byte_index*8);
	              end if;
	            end loop;
	          when others =>
	            slv_reg0 <= slv_reg0;
	            slv_reg1 <= slv_reg1;
	            slv_reg2 <= slv_reg2;
	            slv_reg3 <= slv_reg3;
	            slv_reg4 <= slv_reg4;
	            slv_reg5 <= slv_reg5;
	            slv_reg6 <= slv_reg6;
	            slv_reg7 <= slv_reg7;
	            slv_reg8 <= slv_reg8;
	            slv_reg9 <= slv_reg9;
	            slv_reg10 <= slv_reg10;
	            slv_reg11 <= slv_reg11;
	            slv_reg12 <= slv_reg12;
	            slv_reg13 <= slv_reg13;
	            slv_reg14 <= slv_reg14;
	            slv_reg15 <= slv_reg15;
	            slv_reg16 <= slv_reg16;
	            slv_reg17 <= slv_reg17;
	            slv_reg18 <= slv_reg18;
	            slv_reg19 <= slv_reg19;
	            slv_reg20 <= slv_reg20;
	            slv_reg21 <= slv_reg21;
	            slv_reg22 <= slv_reg22;
	            slv_reg23 <= slv_reg23;
	            slv_reg24 <= slv_reg24;
	            slv_reg25 <= slv_reg25;
	            slv_reg26 <= slv_reg26;
	            slv_reg27 <= slv_reg27;
	            slv_reg28 <= slv_reg28;
	            slv_reg29 <= slv_reg29;
	            slv_reg30 <= slv_reg30;
	            slv_reg31 <= slv_reg31;
--	            slv_reg32 <= slv_reg32;
--	            slv_reg33 <= slv_reg33;
--	            slv_reg34 <= slv_reg34;
--	            slv_reg35 <= slv_reg35;
--	            slv_reg36 <= slv_reg36;
--	            slv_reg37 <= slv_reg37;
--	            slv_reg38 <= slv_reg38;
--	            slv_reg39 <= slv_reg39;
--	            slv_reg40 <= slv_reg40;
--	            slv_reg41 <= slv_reg41;
--	            slv_reg42 <= slv_reg42;
--	            slv_reg43 <= slv_reg43;
--	            slv_reg44 <= slv_reg44;
--	            slv_reg45 <= slv_reg45;
--	            slv_reg46 <= slv_reg46;
--	            slv_reg47 <= slv_reg47;
--	            slv_reg48 <= slv_reg48;
--	            slv_reg49 <= slv_reg49;
--	            slv_reg50 <= slv_reg50;
--	            slv_reg51 <= slv_reg51;
--	            slv_reg52 <= slv_reg52;
--	            slv_reg53 <= slv_reg53;
--	            slv_reg54 <= slv_reg54;
--	            slv_reg55 <= slv_reg55;
--	            slv_reg56 <= slv_reg56;
--	            slv_reg57 <= slv_reg57;
--	            slv_reg58 <= slv_reg58;
--	            slv_reg59 <= slv_reg59;
--	            slv_reg60 <= slv_reg60;
--	            slv_reg61 <= slv_reg61;
--	            slv_reg62 <= slv_reg62;
--	            slv_reg63 <= slv_reg63;
	            slv_reg64 <= slv_reg64;
	        end case;
	      end if;
	    end if;
	  end if;                   
	end process; 

	-- Implement write response logic generation
	-- The write response and response valid signals are asserted by the slave 
	-- when axi_wready, S_AXI_WVALID, axi_wready and S_AXI_WVALID are asserted.  
	-- This marks the acceptance of address and indicates the status of 
	-- write transaction.

	process (S_AXI_ACLK)
	begin
	  if rising_edge(S_AXI_ACLK) then 
	    if S_AXI_ARESETN = '0' then
	      axi_bvalid  <= '0';
	      axi_bresp   <= "00"; --need to work more on the responses
	    else
	      if (axi_awready = '1' and S_AXI_AWVALID = '1' and axi_wready = '1' and S_AXI_WVALID = '1' and axi_bvalid = '0'  ) then
	        axi_bvalid <= '1';
	        axi_bresp  <= "00"; 
	      elsif (S_AXI_BREADY = '1' and axi_bvalid = '1') then   --check if bready is asserted while bvalid is high)
	        axi_bvalid <= '0';                                 -- (there is a possibility that bready is always asserted high)
	      end if;
	    end if;
	  end if;                   
	end process; 

	-- Implement axi_arready generation
	-- axi_arready is asserted for one S_AXI_ACLK clock cycle when
	-- S_AXI_ARVALID is asserted. axi_awready is 
	-- de-asserted when reset (active low) is asserted. 
	-- The read address is also latched when S_AXI_ARVALID is 
	-- asserted. axi_araddr is reset to zero on reset assertion.

	process (S_AXI_ACLK)
	begin
	  if rising_edge(S_AXI_ACLK) then 
	    if S_AXI_ARESETN = '0' then
	      axi_arready <= '0';
	      axi_araddr  <= (others => '1');
	    else
	      if (axi_arready = '0' and S_AXI_ARVALID = '1') then
	        -- indicates that the slave has acceped the valid read address
	        axi_arready <= '1';
	        -- Read Address latching 
	        axi_araddr  <= S_AXI_ARADDR;           
	      else
	        axi_arready <= '0';
	      end if;
	    end if;
	  end if;                   
	end process; 

	-- Implement axi_arvalid generation
	-- axi_rvalid is asserted for one S_AXI_ACLK clock cycle when both 
	-- S_AXI_ARVALID and axi_arready are asserted. The slave registers 
	-- data are available on the axi_rdata bus at this instance. The 
	-- assertion of axi_rvalid marks the validity of read data on the 
	-- bus and axi_rresp indicates the status of read transaction.axi_rvalid 
	-- is deasserted on reset (active low). axi_rresp and axi_rdata are 
	-- cleared to zero on reset (active low).  
	process (S_AXI_ACLK)
	begin
	  if rising_edge(S_AXI_ACLK) then
	    if S_AXI_ARESETN = '0' then
	      axi_rvalid <= '0';
	      axi_rresp  <= "00";
	    else
	      if (axi_arready = '1' and S_AXI_ARVALID = '1' and axi_rvalid = '0') then
	        -- Valid read data is available at the read data bus
	        axi_rvalid <= '1';
	        axi_rresp  <= "00"; -- 'OKAY' response
	      elsif (axi_rvalid = '1' and S_AXI_RREADY = '1') then
	        -- Read data is accepted by the master
	        axi_rvalid <= '0';
	      end if;            
	    end if;
	  end if;
	end process;

	-- Implement memory mapped register select and read logic generation
	-- Slave register read enable is asserted when valid address is available
	-- and the slave is ready to accept the read address.
	slv_reg_rden <= axi_arready and S_AXI_ARVALID and (not axi_rvalid) ;

	process (slv_reg0, slv_reg1, slv_reg2, slv_reg3, slv_reg4, slv_reg5, slv_reg6, slv_reg7, slv_reg8, slv_reg9, slv_reg10, slv_reg11, slv_reg12, slv_reg13, slv_reg14, slv_reg15, slv_reg16, slv_reg17, slv_reg18, slv_reg19, slv_reg20, slv_reg21, slv_reg22, slv_reg23, slv_reg24, slv_reg25, slv_reg26, slv_reg27, slv_reg28, slv_reg29, slv_reg30, slv_reg31, slv_reg32, slv_reg33, slv_reg34, slv_reg35, slv_reg36, slv_reg37, slv_reg38, slv_reg39, slv_reg40, slv_reg41, slv_reg42, slv_reg43, slv_reg44, slv_reg45, slv_reg46, slv_reg47, slv_reg48, slv_reg49, slv_reg50, slv_reg51, slv_reg52, slv_reg53, slv_reg54, slv_reg55, slv_reg56, slv_reg57, slv_reg58, slv_reg59, slv_reg60, slv_reg61, slv_reg62, slv_reg63, slv_reg64, axi_araddr, S_AXI_ARESETN, slv_reg_rden)
	variable loc_addr :std_logic_vector(OPT_MEM_ADDR_BITS downto 0);
	begin
	    -- Address decoding for reading registers
	    loc_addr := axi_araddr(ADDR_LSB + OPT_MEM_ADDR_BITS downto ADDR_LSB);
	    case loc_addr is
	      when b"0000000" =>
	        reg_data_out <= slv_reg0;
	      when b"0000001" =>
	        reg_data_out <= slv_reg1;
	      when b"0000010" =>
	        reg_data_out <= slv_reg2;
	      when b"0000011" =>
	        reg_data_out <= slv_reg3;
	      when b"0000100" =>
	        reg_data_out <= slv_reg4;
	      when b"0000101" =>
	        reg_data_out <= slv_reg5;
	      when b"0000110" =>
	        reg_data_out <= slv_reg6;
	      when b"0000111" =>
	        reg_data_out <= slv_reg7;
	      when b"0001000" =>
	        reg_data_out <= slv_reg8;
	      when b"0001001" =>
	        reg_data_out <= slv_reg9;
	      when b"0001010" =>
	        reg_data_out <= slv_reg10;
	      when b"0001011" =>
	        reg_data_out <= slv_reg11;
	      when b"0001100" =>
	        reg_data_out <= slv_reg12;
	      when b"0001101" =>
	        reg_data_out <= slv_reg13;
	      when b"0001110" =>
	        reg_data_out <= slv_reg14;
	      when b"0001111" =>
	        reg_data_out <= slv_reg15;
	      when b"0010000" =>
	        reg_data_out <= slv_reg16;
	      when b"0010001" =>
	        reg_data_out <= slv_reg17;
	      when b"0010010" =>
	        reg_data_out <= slv_reg18;
	      when b"0010011" =>
	        reg_data_out <= slv_reg19;
	      when b"0010100" =>
	        reg_data_out <= slv_reg20;
	      when b"0010101" =>
	        reg_data_out <= slv_reg21;
	      when b"0010110" =>
	        reg_data_out <= slv_reg22;
	      when b"0010111" =>
	        reg_data_out <= slv_reg23;
	      when b"0011000" =>
	        reg_data_out <= slv_reg24;
	      when b"0011001" =>
	        reg_data_out <= slv_reg25;
	      when b"0011010" =>
	        reg_data_out <= slv_reg26;
	      when b"0011011" =>
	        reg_data_out <= slv_reg27;
	      when b"0011100" =>
	        reg_data_out <= slv_reg28;
	      when b"0011101" =>
	        reg_data_out <= slv_reg29;
	      when b"0011110" =>
	        reg_data_out <= slv_reg30;
	      when b"0011111" =>
	        reg_data_out <= slv_reg31;
	      when b"0100000" =>
	        reg_data_out <= slv_reg32;
	      when b"0100001" =>
	        reg_data_out <= slv_reg33;
	      when b"0100010" =>
	        reg_data_out <= slv_reg34;
	      when b"0100011" =>
	        reg_data_out <= slv_reg35;
	      when b"0100100" =>
	        reg_data_out <= slv_reg36;
	      when b"0100101" =>
	        reg_data_out <= slv_reg37;
	      when b"0100110" =>
	        reg_data_out <= slv_reg38;
	      when b"0100111" =>
	        reg_data_out <= slv_reg39;
	      when b"0101000" =>
	        reg_data_out <= slv_reg40;
	      when b"0101001" =>
	        reg_data_out <= slv_reg41;
	      when b"0101010" =>
	        reg_data_out <= slv_reg42;
	      when b"0101011" =>
	        reg_data_out <= slv_reg43;
	      when b"0101100" =>
	        reg_data_out <= slv_reg44;
	      when b"0101101" =>
	        reg_data_out <= slv_reg45;
	      when b"0101110" =>
	        reg_data_out <= slv_reg46;
	      when b"0101111" =>
	        reg_data_out <= slv_reg47;
	      when b"0110000" =>
	        reg_data_out <= slv_reg48;
	      when b"0110001" =>
	        reg_data_out <= slv_reg49;
	      when b"0110010" =>
	        reg_data_out <= slv_reg50;
	      when b"0110011" =>
	        reg_data_out <= slv_reg51;
	      when b"0110100" =>
	        reg_data_out <= slv_reg52;
	      when b"0110101" =>
	        reg_data_out <= slv_reg53;
	      when b"0110110" =>
	        reg_data_out <= slv_reg54;
	      when b"0110111" =>
	        reg_data_out <= slv_reg55;
	      when b"0111000" =>
	        reg_data_out <= slv_reg56;
	      when b"0111001" =>
	        reg_data_out <= slv_reg57;
	      when b"0111010" =>
	        reg_data_out <= slv_reg58;
	      when b"0111011" =>
	        reg_data_out <= slv_reg59;
	      when b"0111100" =>
	        reg_data_out <= slv_reg60;
	      when b"0111101" =>
	        reg_data_out <= slv_reg61;
	      when b"0111110" =>
	        reg_data_out <= slv_reg62;
	      when b"0111111" =>
	        reg_data_out <= slv_reg63;
	      when b"1000000" =>
	        reg_data_out <= slv_reg64;
	      when others =>
	        reg_data_out  <= (others => '0');
	    end case;
	end process; 

	-- Output register or memory read data
	process( S_AXI_ACLK ) is
	begin
	  if (rising_edge (S_AXI_ACLK)) then
	    if ( S_AXI_ARESETN = '0' ) then
	      axi_rdata  <= (others => '0');
	    else
	      if (slv_reg_rden = '1') then
	        -- When there is a valid read address (S_AXI_ARVALID) with 
	        -- acceptance of read address by the slave (axi_arready), 
	        -- output the read dada 
	        -- Read address mux
	          axi_rdata <= reg_data_out;     -- register read data
	      end if;   
	    end if;
	  end if;
	end process;


	-- Add user logic here
mat <= ((signed(slv_reg0(31 downto 16)),signed(slv_reg0(15 downto 0)),signed(slv_reg1(31 downto 16)),signed(slv_reg1(15 downto 0)),signed(slv_reg2(31 downto 16)),signed(slv_reg2(15 downto 0)),signed(slv_reg3(31 downto 16)),signed(slv_reg3(15 downto 0))),
(signed(slv_reg4(31 downto 16)),signed(slv_reg4(15 downto 0)),signed(slv_reg5(31 downto 16)),signed(slv_reg5(15 downto 0)),signed(slv_reg6(31 downto 16)),signed(slv_reg6(15 downto 0)),signed(slv_reg7(31 downto 16)),signed(slv_reg7(15 downto 0))),
(signed(slv_reg8(31 downto 16)),signed(slv_reg8(15 downto 0)),signed(slv_reg9(31 downto 16)),signed(slv_reg9(15 downto 0)),signed(slv_reg10(31 downto 16)),signed(slv_reg10(15 downto 0)),signed(slv_reg11(31 downto 16)),signed(slv_reg11(15 downto 0))),
(signed(slv_reg12(31 downto 16)),signed(slv_reg12(15 downto 0)),signed(slv_reg13(31 downto 16)),signed(slv_reg13(15 downto 0)),signed(slv_reg14(31 downto 16)),signed(slv_reg14(15 downto 0)),signed(slv_reg15(31 downto 16)),signed(slv_reg15(15 downto 0))),
(signed(slv_reg16(31 downto 16)),signed(slv_reg16(15 downto 0)),signed(slv_reg17(31 downto 16)),signed(slv_reg17(15 downto 0)),signed(slv_reg18(31 downto 16)),signed(slv_reg18(15 downto 0)),signed(slv_reg19(31 downto 16)),signed(slv_reg19(15 downto 0))),
(signed(slv_reg20(31 downto 16)),signed(slv_reg20(15 downto 0)),signed(slv_reg21(31 downto 16)),signed(slv_reg21(15 downto 0)),signed(slv_reg22(31 downto 16)),signed(slv_reg22(15 downto 0)),signed(slv_reg23(31 downto 16)),signed(slv_reg23(15 downto 0))),
(signed(slv_reg24(31 downto 16)),signed(slv_reg24(15 downto 0)),signed(slv_reg25(31 downto 16)),signed(slv_reg25(15 downto 0)),signed(slv_reg26(31 downto 16)),signed(slv_reg26(15 downto 0)),signed(slv_reg27(31 downto 16)),signed(slv_reg27(15 downto 0))),
(signed(slv_reg28(31 downto 16)),signed(slv_reg28(15 downto 0)),signed(slv_reg29(31 downto 16)),signed(slv_reg29(15 downto 0)),signed(slv_reg30(31 downto 16)),signed(slv_reg30(15 downto 0)),signed(slv_reg31(31 downto 16)),signed(slv_reg31(15 downto 0))));
--al <= signed(slv_reg64(15 downto 0));
A: process (S_AXI_ACLK)
--TYPE matrixs IS ARRAY (0 TO 7, 0 TO 7) OF SIGNED(31 downto 0);
--TYPE matrixs2 IS ARRAY (0 TO 7, 0 TO 7) OF SIGNED(43 downto 0);

variable mat_tr: matrix;
variable mat3: matrix;
----creo que el tama�o de mat3 debe cambiar
--variable mod1: integer range 0 to 32;
--variable mod2: integer range 0 to 32;
--variable cos_pm: signed(15 downto 0);
--variable alpha1_mul: signed(31 downto 0);
--variable alpha2_mul: signed(31 downto 0);
--variable alpha3_mul: signed(31 downto 0);
--variable alpha4_mul: signed(31 downto 0);
--variable alpha5_mul: signed(31 downto 0);

--variable b4: signed(15 downto 0);
--variable b5: signed(15 downto 0);
--variable b6: signed(15 downto 0);
--variable c2: signed(15 downto 0); 
--variable c3: signed(15 downto 0); 
--variable c4: signed(15 downto 0);
--variable c5: signed(15 downto 0);
--variable c6: signed(15 downto 0);
--variable d2: signed(15 downto 0);
--variable d3: signed(15 downto 0); 
--variable d4: signed(15 downto 0); 
--variable d5: signed(15 downto 0);
--variable alpha1_mul1: signed(31 downto 0);
--variable alpha2_mul1: signed(31 downto 0);
--variable alpha3_mul1: signed(31 downto 0);
--variable alpha4_mul1: signed(31 downto 0);
--variable alpha5_mul1: signed(31 downto 0);

--variable b41: signed(15 downto 0);
--variable b51: signed(15 downto 0);
--variable b61: signed(15 downto 0);
--variable c21: signed(15 downto 0); 
--variable c31: signed(15 downto 0); 
--variable c41: signed(15 downto 0);
--variable c51: signed(15 downto 0);
--variable c61: signed(15 downto 0);
--variable d21: signed(15 downto 0);
--variable d31: signed(15 downto 0); 
--variable d41: signed(15 downto 0); 
--variable d51: signed(15 downto 0);    
--variable cos_qn: signed(15 downto 0);

variable a0: signed(15 downto 0);
variable a1: signed(15 downto 0);
variable a2: signed(15 downto 0);
variable a3: signed(15 downto 0);
variable a4: signed(15 downto 0);
variable a5: signed(15 downto 0);
variable a6: signed(15 downto 0);
variable a7: signed(15 downto 0);

variable b0: signed(15 downto 0);
variable b1: signed(15 downto 0);

variable a01: signed(15 downto 0);
variable a11: signed(15 downto 0);
variable a21: signed(15 downto 0);
variable a31: signed(15 downto 0);
variable a41: signed(15 downto 0);
variable a51: signed(15 downto 0);
variable a61: signed(15 downto 0);
variable a71: signed(15 downto 0);

variable b01: signed(15 downto 0);
variable b11: signed(15 downto 0);
begin
    
   
   

    --habr� error con lo que no se multiplica por alpha
    for p in 0 to 7 loop
    --se reduce mucho si se guardan los terminos de las sumas para no volver a realizarlas

--        alpha1_mul := (b2+b3)*alpha(1); --c2
--        alpha2_mul := b4*alpha(2);  --c3
--        alpha3_mul := b5*alpha(3);  --c4
--        alpha4_mul := b6*alpha(4);  --c5
--        alpha5_mul := (b4+b6)*alpha(5); --c6
--        d2  :=resize(signed(alpha2_mul(31 downto 14)),16) - resize(signed(alpha5_mul(31 downto 14)),16);
--        d3  :=resize(signed(alpha3_mul(31 downto 14)),16) + a7;
--        d4  :=resize(signed(alpha4_mul(31 downto 14)),16) - resize(signed(alpha5_mul(31 downto 14)),16);
--        d5  :=a7- resize(signed(alpha3_mul(31 downto 14)),16);
        a0 := mat(p,0) + mat(p,7);
        a1 := mat(p,1) + mat(p,6);
        a2 := mat(p,2) + mat(p,5);
        a3 := mat(p,3) + mat(p,4);
        a4 := mat(p,3) - mat(p,4);
        a5 := mat(p,2) - mat(p,5);
        a6 := mat(p,1) - mat(p,6);
        a7 := mat(p,0) - mat(p,7);
        b0 := a0 + a3;
        b1 := a1 + a2;
        
        mat3(p,0) := b0 + b1;
        mat3(p,1) := a6 + a7;
        mat3(p,2) := a5;
        mat3(p,3) := mat(p,3) - mat(p,4);
        mat3(p,4) := a0 - a3;
        mat3(p,5) := mat(p,1) - mat(p,2);
        mat3(p,6) := a7 - a6;
        mat3(p,7) := b0 - b1;
--        mat2(p,0) <= b0+b1;
--        mat2(p,1) <= d3+d4;
--        mat2(p,2) <= resize(signed(alpha1_mul(31 downto 14)),16)+b3;
--        mat2(p,3) <= d5-d2;
--        mat2(p,4) <= b0-b1;
--        mat2(p,5) <= d2+d5;
--        mat2(p,6) <= b3 - resize(signed(alpha1_mul(31 downto 14)),16);
--        mat2(p,7) <= d3-d4;
--        mat2(p,0) <= b0;
--        mat2(p,1) <= b1;
--        mat2(p,2) <= b2;
--        mat2(p,3) <= b3;
--        mat2(p,4) <= b4;
--        mat2(p,5) <= b5;
--        mat2(p,6) <= b6;
--        mat2(p,7) <= a7;
    end loop;
    
    for a in 0 to 7 loop
        for b in 0 to 7 loop
            mat_tr(a,b) := mat3(b,a);
            --mat_tr(a,b) := mat3(b,a)(43 downto 14); ---------------revisar
        end loop;
    end loop;
    
   for p in 0 to 7 loop

--        b41 := -a41 - a51;
--        b51 := a51 + a61;
--        b61 := a61 + a71;
--        alpha1_mul1 := (b21+b31)*alpha(1); --c2
--        alpha2_mul1 := b41*alpha(2);  --c3
--        alpha3_mul1 := b51*alpha(3);  --c4
--        alpha4_mul1 := b61*alpha(4);  --c5
--        alpha5_mul1 := (b41+b61)*alpha(5); --c6
--        d21  :=resize(signed(alpha2_mul1(31 downto 14)),16) - resize(signed(alpha5_mul1(31 downto 14)),16);
--        d31  :=resize(signed(alpha3_mul1(31 downto 14)),16) + a71;
--        d41  :=resize(signed(alpha4_mul1(31 downto 14)),16) - resize(signed(alpha5_mul1(31 downto 14)),16);
--        d51  :=a71- resize(signed(alpha3_mul1(31 downto 14)),16);
        a01 := mat_tr(p,0) + mat_tr(p,7);
        a11 := mat_tr(p,1) + mat_tr(p,6);
        a21 := mat_tr(p,2) + mat_tr(p,5);
        a31 := mat_tr(p,3) + mat_tr(p,4);
        a41 := mat_tr(p,3) - mat_tr(p,4);
        a51 := mat_tr(p,2) - mat_tr(p,5);
        a61 := mat_tr(p,1) - mat_tr(p,6);
        a71 := mat_tr(p,0) - mat_tr(p,7);
        b01 := a0 + a3;
        b11 := a1 + a2;
        
        mat2(p,0) <= b01 + b11;
        mat2(p,1) <= a61 + a71;
        mat2(p,2) <= a51;
        mat2(p,3) <= mat_tr(p,3) - mat_tr(p,4);
        mat2(p,4) <= a01 - a31;
        mat2(p,5) <= mat_tr(p,1) - mat_tr(p,2);
        mat2(p,6) <= a71 - a61;
        mat2(p,7) <= b01 - b11;
--        mat2(p,0) <= mat_tr(p,0) + mat_tr(p,1) + mat_tr(p,2) + mat_tr(p,3) + mat_tr(p,4) + mat_tr(p,5) + mat_tr(p,6) + mat_tr(p,7);
--        mat2(p,1) <= mat_tr(p,0) + mat_tr(p,1) - mat_tr(p,6) - mat_tr(p,7);
--        mat2(p,2) <= mat_tr(p,0) + (mat_tr(p,1)) - (mat_tr(p,2)) - mat_tr(p,3) - mat_tr(p,4) - (mat_tr(p,5)) + (mat_tr(p,6)) + mat_tr(p,7);
--        mat2(p,3) <= mat_tr(p,2) - mat_tr(p,5);
--        mat2(p,4) <= mat_tr(p,0) - mat_tr(p,1) - mat_tr(p,2) + mat_tr(p,3) + mat_tr(p,4) - mat_tr(p,5) - mat_tr(p,6) + mat_tr(p,7);
--        mat2(p,5) <= mat_tr(p,3) - mat_tr(p,4);
--        mat2(p,6) <= mat_tr(p,0) - mat_tr(p,1) + mat_tr(p,6) - mat_tr(p,7);
--        mat2(p,7) <= (mat_tr(p,0)) - mat_tr(p,1) + mat_tr(p,2) - (mat_tr(p,3)) - (mat_tr(p,4)) + mat_tr(p,5) - mat_tr(p,6) + (mat_tr(p,7));

        --tengo que hacer un resize de mi numero que guardar�a en los bits 31 al 14 de 18 bits a 16 
        --para poder asignat a las matrices
        --el mejor modo de quitar bits es hacer un corrimiento
        
--        mat2(p,0) <= mat_tr(p,0) + mat_tr(p,1) + mat_tr(p,2) + mat_tr(p,3) + mat_tr(p,4) + mat_tr(p,5) + mat_tr(p,6) + mat_tr(p,7);
--        mat2(p,1) <= mat_tr(p,0) + mat_tr(p,7) - alpha(5)*(mat_tr(p,0)+mat_tr(p,1)-mat_tr(p,2)-mat_tr(p,3)+mat_tr(p,4)+mat_tr(p,5)-mat_tr(p,6)-mat_tr(p,7)) + alpha(3)*(mat_tr(p,1)+mat_tr(p,2)-mat_tr(p,5)-mat_tr(p,6)) + alpha(4)*(mat_tr(p,0)+mat_tr(p,1)-mat_tr(p,6)-mat_tr(p,7));
--        mat2(p,2) <= mat_tr(p,0) - mat_tr(p,3) - mat_tr(p,4) + mat_tr(p,7) + alpha(1)*(mat_tr(p,0)+mat_tr(p,1)-mat_tr(p,2)-mat_tr(p,3)-mat_tr(p,4)-mat_tr(p,5)+mat_tr(p,6)+mat_tr(p,7));
--        mat2(p,3) <= mat_tr(p,0) - mat_tr(p,7) + alpha(5)*(mat_tr(p,0)+mat_tr(p,1)-mat_tr(p,2)-mat_tr(p,3)+mat_tr(p,4)+mat_tr(p,5)-mat_tr(p,6)-mat_tr(p,7)) + alpha(2)*(mat_tr(p,2)+mat_tr(p,3)-mat_tr(p,4)-mat_tr(p,5)) - alpha(3)*(mat_tr(p,1)+mat_tr(p,2)-mat_tr(p,5)-mat_tr(p,6));
--        mat2(p,4) <= mat_tr(p,0) - mat_tr(p,1) - mat_tr(p,2) + mat_tr(p,3) + mat_tr(p,4) - mat_tr(p,5) - mat_tr(p,6) + mat_tr(p,7);
--        mat2(p,5) <= mat_tr(p,0) - mat_tr(p,7) - alpha(5)*(mat_tr(p,0)+mat_tr(p,1)-mat_tr(p,2)-mat_tr(p,3)+mat_tr(p,4)+mat_tr(p,5)-mat_tr(p,6)-mat_tr(p,7)) - alpha(2)*(mat_tr(p,2)+mat_tr(p,3)-mat_tr(p,4)-mat_tr(p,5)) - alpha(3)*(mat_tr(p,1)+mat_tr(p,2)-mat_tr(p,5)-mat_tr(p,6));
--        mat2(p,6) <= mat_tr(p,0) - mat_tr(p,3) - mat_tr(p,4) + mat_tr(p,7) - alpha(1)*(mat_tr(p,0)+mat_tr(p,1)-mat_tr(p,2)-mat_tr(p,3)-mat_tr(p,4)-mat_tr(p,5)+mat_tr(p,6)+mat_tr(p,7));
--        mat2(p,7) <= mat_tr(p,0) - mat_tr(p,7) - alpha(5)*(mat_tr(p,0)+mat_tr(p,1)-mat_tr(p,2)-mat_tr(p,3)+mat_tr(p,4)+mat_tr(p,5)-mat_tr(p,6)-mat_tr(p,7)) + alpha(3)*(mat_tr(p,1)+mat_tr(p,2)-mat_tr(p,5)-mat_tr(p,6)) - alpha(4)*(mat_tr(p,0)+mat_tr(p,1)-mat_tr(p,6)-mat_tr(p,7));
    end loop;
    

    
end process A;

    slv_reg32(15 downto 0) <= std_logic_vector(mat2(0,0));
    slv_reg32(31 downto 16) <= std_logic_vector(mat2(0,1));
    slv_reg33(15 downto 0) <= std_logic_vector(mat2(0,2));
    slv_reg33(31 downto 16) <= std_logic_vector(mat2(0,3));
    slv_reg34(15 downto 0) <= std_logic_vector(mat2(0,4));
    slv_reg34(31 downto 16) <= std_logic_vector(mat2(0,5));
    slv_reg35(15 downto 0) <= std_logic_vector(mat2(0,6));
    slv_reg35(31 downto 16) <= std_logic_vector(mat2(0,7));
    slv_reg36(15 downto 0) <= std_logic_vector(mat2(1,0));
    slv_reg36(31 downto 16) <= std_logic_vector(mat2(1,1));
    slv_reg37(15 downto 0) <= std_logic_vector(mat2(1,2));
    slv_reg37(31 downto 16) <= std_logic_vector(mat2(1,3));
    slv_reg38(15 downto 0) <= std_logic_vector(mat2(1,4));
    slv_reg38(31 downto 16) <= std_logic_vector(mat2(1,5));
    slv_reg39(15 downto 0) <= std_logic_vector(mat2(1,6));
    slv_reg39(31 downto 16) <= std_logic_vector(mat2(1,7));
    slv_reg40(15 downto 0) <= std_logic_vector(mat2(2,0));
    slv_reg40(31 downto 16) <= std_logic_vector(mat2(2,1));
    slv_reg41(15 downto 0) <= std_logic_vector(mat2(2,2));
    slv_reg41(31 downto 16) <= std_logic_vector(mat2(2,3));
    slv_reg42(15 downto 0) <= std_logic_vector(mat2(2,4));
    slv_reg42(31 downto 16) <= std_logic_vector(mat2(2,5));
    slv_reg43(15 downto 0) <= std_logic_vector(mat2(2,6));
    slv_reg43(31 downto 16) <= std_logic_vector(mat2(2,7));
    slv_reg44(15 downto 0) <= std_logic_vector(mat2(3,0));
    slv_reg44(31 downto 16) <= std_logic_vector(mat2(3,1));
    slv_reg45(15 downto 0) <= std_logic_vector(mat2(3,2));
    slv_reg45(31 downto 16) <= std_logic_vector(mat2(3,3));
    slv_reg46(15 downto 0) <= std_logic_vector(mat2(3,4));
    slv_reg46(31 downto 16) <= std_logic_vector(mat2(3,5));
    slv_reg47(15 downto 0) <= std_logic_vector(mat2(3,6));
    slv_reg47(31 downto 16) <= std_logic_vector(mat2(3,7));
    slv_reg48(15 downto 0) <= std_logic_vector(mat2(4,0));
    slv_reg48(31 downto 16) <= std_logic_vector(mat2(4,1));
    slv_reg49(15 downto 0) <= std_logic_vector(mat2(4,2));
    slv_reg49(31 downto 16) <= std_logic_vector(mat2(4,3));
    slv_reg50(15 downto 0) <= std_logic_vector(mat2(4,4));
    slv_reg50(31 downto 16) <= std_logic_vector(mat2(4,5));
    slv_reg51(15 downto 0) <= std_logic_vector(mat2(4,6));
    slv_reg51(31 downto 16) <= std_logic_vector(mat2(4,7));
    slv_reg52(15 downto 0) <= std_logic_vector(mat2(5,0));
    slv_reg52(31 downto 16) <= std_logic_vector(mat2(5,1));
    slv_reg53(15 downto 0) <= std_logic_vector(mat2(5,2));
    slv_reg53(31 downto 16) <= std_logic_vector(mat2(5,3));
    slv_reg54(15 downto 0) <= std_logic_vector(mat2(5,4));
    slv_reg54(31 downto 16) <= std_logic_vector(mat2(5,5));
    slv_reg55(15 downto 0) <= std_logic_vector(mat2(5,6));
    slv_reg55(31 downto 16) <= std_logic_vector(mat2(5,7));
    slv_reg56(15 downto 0) <= std_logic_vector(mat2(6,0));
    slv_reg56(31 downto 16) <= std_logic_vector(mat2(6,1));
    slv_reg57(15 downto 0) <= std_logic_vector(mat2(6,2));
    slv_reg57(31 downto 16) <= std_logic_vector(mat2(6,3));
    slv_reg58(15 downto 0) <= std_logic_vector(mat2(6,4));
    slv_reg58(31 downto 16) <= std_logic_vector(mat2(6,5));
    slv_reg59(15 downto 0) <= std_logic_vector(mat2(6,6));
    slv_reg59(31 downto 16) <= std_logic_vector(mat2(6,7));
    slv_reg60(15 downto 0) <= std_logic_vector(mat2(7,0));
    slv_reg60(31 downto 16) <= std_logic_vector(mat2(7,1));
    slv_reg61(15 downto 0) <= std_logic_vector(mat2(7,2));
    slv_reg61(31 downto 16) <= std_logic_vector(mat2(7,3));
    slv_reg62(15 downto 0) <= std_logic_vector(mat2(7,4));
    slv_reg62(31 downto 16) <= std_logic_vector(mat2(7,5));
    slv_reg63(15 downto 0) <= std_logic_vector(mat2(7,6));
    slv_reg63(31 downto 16) <= std_logic_vector(mat2(7,7));
	-- User logic ends

end arch_imp;
