

proc generate {drv_handle} {
	xdefine_include_file $drv_handle "xparameters.h" "DCT8x8_BAS2008" "NUM_INSTANCES" "DEVICE_ID"  "C_S00_AXI_BASEADDR" "C_S00_AXI_HIGHADDR"
}
