

/***************************** Include Files *******************************/
#include "DCT8x8rc_BrahimiNovel.h"

/************************** Function Definitions ***************************/
